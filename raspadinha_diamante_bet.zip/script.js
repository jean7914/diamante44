let saldo = 10;
function entrar() {
  const email = document.getElementById('email').value;
  const senha = document.getElementById('senha').value;
  if (email && senha) {
    document.getElementById('login').style.display = 'none';
    document.getElementById('jogo').style.display = 'block';
    atualizarSaldo();
  } else {
    alert("Preencha todos os campos.");
  }
}
function atualizarSaldo() {
  document.getElementById('saldo').innerText = saldo.toFixed(2);
}
function mostrarPix() {
  document.getElementById('pix').style.display = 'block';
}
function jogar() {
  if (saldo < 1) {
    alert("Saldo insuficiente! Faça um depósito.");
    return;
  }
  saldo -= 1;
  atualizarSaldo();
  const caixas = document.getElementById('caixas');
  caixas.innerHTML = '';
  for (let i = 0; i < 8; i++) {
    const div = document.createElement('div');
    div.className = 'caixa';
    div.onclick = () => revelar(div);
    caixas.appendChild(div);
  }
}
function revelar(div) {
  if (div.classList.contains('revelado')) return;
  div.classList.add('revelado');
  const sorte = Math.random();
  if (sorte < 0.25) {
    div.className = 'resultado';
    div.style.backgroundImage = "url('imagens/diamante.png')";
    saldo += 1;
  } else {
    div.className = 'resultado';
    div.style.backgroundImage = "url('imagens/bomba.png')";
    saldo -= 2;
  }
  atualizarSaldo();
}